# Typings for JavaScript APIs available within Google Colaboratory

This repository contains the public APIs available to custom JavaScript running
within the execution outputs of Google Colaboratory.

Examples using many of these APIs can be found within the
[Advanced Outputs](https://colab.research.google.com/notebooks/snippets/advanced_outputs.ipynb)
notebook.
