:mod:`aptsources.distro` --- Distribution abstraction of the sources.list
===============================================================================
.. note::

    This part of the documentation is created automatically.


.. automodule:: aptsources.distro
    :members:
    :undoc-members:

